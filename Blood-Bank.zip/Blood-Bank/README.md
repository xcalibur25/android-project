# Blood-Bank
Android app connected to a database of blood doner
You can download the app from the link https://1drv.ms/u/s!AgwRW8KeY2FEvl9KTtcOzK1Q38A-

The android app is a community between people who need blood and who are wiling to donote blood. The home page of the app is looked like this. Which has maily two option, one for "Need Blood" and the other is "Be a Donor"

<p align="center">
  <img src="https://github.com/Bikash300895/Blood-Bank/blob/master/ScreenShoot/1.png" width="250"/>
</p>

If you are willing to be a donor all you have to do is to go to the "Be a Donor page and fill the form the form will look like below. Here you have to provide Your name, city from the frop down menu, your blood group and a mobile number to contuct with you.
And Click "Continue"

<p align="center">
  <img src="https://github.com/Bikash300895/Blood-Bank/blob/master/ScreenShoot/2.png" width="250"/>
</p>

As soon as you become a donor any one who is in your city and need blood of your group can find you from "Need Blood" section. All he has to do is to select and required blood group and click "Continue". This section will look like this...

<p align="center">
  <img src="https://github.com/Bikash300895/Blood-Bank/blob/master/ScreenShoot/3.png" width="250"/>
</p>

And finally he will get a list of donors as follow

<p align="center">
  <img src="https://github.com/Bikash300895/Blood-Bank/blob/master/ScreenShoot/4.png" width="250"/>
</p>

You can find the donors in map. The green dot in the map is your position and the red dots the the donors.
<p align="center">
  <img src="https://github.com/Bikash300895/Blood-Bank/blob/master/ScreenShoot/5.png" width="250"/>
</p>

You can also learn about why you should donote blood, and why it is beneficial for you to donote. And ofcourse you may need blood any time you don't know. So, stay connected with the community.


Thank you<br/>

<br/>
Developers<br/>
Shuvendy Roy Bikash<br/>
cse, kuet<br/>
<br/>
Hasib Iqbal Pranto<br/>
cse, kuet<br/>
